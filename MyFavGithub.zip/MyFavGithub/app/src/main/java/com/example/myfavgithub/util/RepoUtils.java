package com.example.myfavgithub.util;

import androidx.recyclerview.widget.DiffUtil;

import com.example.myfavgithub.repodb.Entity;

import java.util.List;

public class RepoUtils extends DiffUtil.Callback  {

    private List<Entity> oldList;
    private List<Entity> newList;

    public RepoUtils(List<Entity> oldList, List<Entity> newList) {
        this.oldList = oldList;
        this.newList = newList;
    }

    @Override
    public int getOldListSize() {
        return oldList.size();
    }

    @Override
    public int getNewListSize() {
        return newList.size();
    }

    @Override
    public boolean areItemsTheSame(int oldItemPosition, int newItemPosition) {
        return oldList.get(oldItemPosition).equals(newList.get(newItemPosition));
    }

    @Override
    public boolean areContentsTheSame(int oldItemPosition, int newItemPosition) {
        Entity oldRepo = oldList.get(oldItemPosition);
        Entity newRepo = newList.get(newItemPosition);
        return oldRepo.getRepositoryName().equals(newRepo.getRepositoryName())
                && oldRepo.getDescriptionRepo().equals(newRepo.getDescriptionRepo())
                && oldRepo.getHtmlUrl().equals(newRepo.getHtmlUrl())
                && oldRepo.getOwnerName().equals(newRepo.getOwnerName());
    }
}


