package com.example.myfavgithub.adapter;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.DiffUtil;
import androidx.recyclerview.widget.RecyclerView;

import com.example.myfavgithub.R;
import com.example.myfavgithub.repodb.Entity;
import com.example.myfavgithub.util.RepoUtils;

import java.util.List;

public class RepoAdapter extends RecyclerView.Adapter<RepoAdapter.RepoViewHolder> {
    private List<Entity> repoList;
    private OnItemClickListener onItemClickListener;

    public RepoAdapter(OnItemClickListener onItemClickListener) {
        this.onItemClickListener = onItemClickListener;
    }

    public void setData(List<Entity> repoList) {
        RepoUtils repoDiffUtil = new RepoUtils(this.repoList, repoList);
        DiffUtil.DiffResult repoUtilResult = DiffUtil.calculateDiff(repoDiffUtil);
        this.repoList = repoList;
        repoUtilResult.dispatchUpdatesTo(this);
    }


    @NonNull
    @Override
    public RepoViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext()).inflate(R.layout.single_repo, parent, false);
        return new RepoViewHolder(itemView, onItemClickListener);
    }

    @Override
    public void onBindViewHolder(@NonNull RepoViewHolder holder, int position) {
        Entity repo = repoList.get(position);
        holder.bind(repo);
    }

    @Override
    public int getItemCount() {
        return repoList != null ? repoList.size() : 0;
    }

    static class RepoViewHolder extends RecyclerView.ViewHolder {

        private OnItemClickListener onItemClickListener;
        private TextView repoTitleTextView;
        private TextView repoDescriptionTextView;

        public RepoViewHolder(@NonNull View itemView, OnItemClickListener onItemClickListener) {
            super(itemView);
            this.onItemClickListener = onItemClickListener;

            itemView.setOnClickListener(v -> onItemClickListener.onClick(getAdapterPosition()));
            itemView.findViewById(R.id.share_btn).setOnClickListener(v -> onItemClickListener.onShareButtonClick(getAdapterPosition()));

            repoTitleTextView = itemView.findViewById(R.id.repo_title);
            repoDescriptionTextView = itemView.findViewById(R.id.repo_description);
        }

        public void bind(Entity repotity) {
            repoTitleTextView.setText(repotity.getRepositoryName());
            repoDescriptionTextView.setText(repotity.getDescriptionRepo());
        }
    }

    public interface OnItemClickListener {
        void onClick(int position);
        void onShareButtonClick(int position);
    }

}
