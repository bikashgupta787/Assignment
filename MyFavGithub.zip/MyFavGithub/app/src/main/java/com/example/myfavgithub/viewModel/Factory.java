package com.example.myfavgithub.viewModel;

import androidx.lifecycle.ViewModel;
import androidx.lifecycle.ViewModelProvider;
import androidx.room.Dao;

import com.example.myfavgithub.Repository;
import com.example.myfavgithub.repodb.OnDataBaseAction;

public class Factory implements ViewModelProvider.Factory {
    private final OnDataBaseAction dao;
    private Repository repository;

    public Factory(OnDataBaseAction dao) {
        this.dao = dao;
        this.repository = new Repository(dao);
    }

    @Override
    public <T extends ViewModel> T create(Class<T> modelClass) {
        return (T) new ApiViewModel(repository);
    }
}
