package com.example.myfavgithub.api;

public class Const {
    public static final String BASE_URL = "https://api.github.com/repos/";
}
