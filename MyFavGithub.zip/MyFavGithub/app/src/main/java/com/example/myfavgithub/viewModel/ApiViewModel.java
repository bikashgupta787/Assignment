package com.example.myfavgithub.viewModel;

import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

import com.example.myfavgithub.model.Repo;
import com.example.myfavgithub.repodb.Entity;
import com.example.myfavgithub.Repository;

import java.io.IOException;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

import kotlin.coroutines.Continuation;
import kotlinx.coroutines.CoroutineStart;
import kotlinx.coroutines.Dispatchers;
import retrofit2.Call;
import retrofit2.Response;

public class ApiViewModel  extends ViewModel {

    private Repository repository;
    private MutableLiveData<Response<Repo>> repoResponse = new MutableLiveData<>();


    public ApiViewModel(Repository repository) {
        this.repository = repository;
        this.repoResponse = new MutableLiveData<Response<Repo>>();
    }

    public MutableLiveData<Response<Repo>> getRepoResponse() {
        return repoResponse;
    }

    //private ExecutorService executorService = Executors.newSingleThreadExecutor();

//    public void githubRepository(String ownerName, String repoName)  {
//        executorService.execute(new Runnable() {
//            @Override
//            public void run() {
//                Response<Repo> response = null;
//                response = repository.getRepo(ownerName, repoName);
//                repoResponse.postValue(response);
//            }
//        });
//    }

    public void githubRepository(String ownerName, String repoName) {
        ExecutorService executorService = Executors.newSingleThreadExecutor();
        executorService.execute(new Runnable() {
            @Override
            public void run() {
                Response<Repo> response = repository.getRepo(ownerName, repoName);
                repoResponse.postValue(response);
            }
        });
        executorService.shutdown();
    }

    public void getTheRepo() {
        ExecutorService executorService = Executors.newSingleThreadExecutor();
        Callable<Void> callable = () -> {
            repository.getAllTheRepo();
            return null;
        };
        Future<Void> future = executorService.submit(callable);
        executorService.shutdown();
    }

    public void insertTheRepo(Entity entity) {
        ExecutorService executorService = Executors.newSingleThreadExecutor();
        executorService.execute(() -> {
            repository.insertTheRepo(entity);
        });

        // Shutdown the executor service when you're done
        executorService.shutdown();    }

    public void deleteTheRepo(Entity entity) {
        ExecutorService executorService = Executors.newSingleThreadExecutor();
        executorService.execute(() -> {
            repository.deleteTheRepo(entity);
        });
        executorService.shutdown();    }

//    public void deleteEntireDb() {
//        viewModelScope.launch(Dispatchers.IO, () -> repository.deleteEntireDb());
//    }



//    public MutableLiveData<Response<Branch>> getBranchResponse() {
//        return branchResponse;
//    }
//
//    public MutableLiveData<Response<List<CommitItem>>> getCommitMessageResponse() {
//        return commitMessageResponse;
//    }
//
//    public MutableLiveData<Response<List<IssueCollection>>> getOpenIssueResponse() {
//        return openIssueResponse;
//    }
}
