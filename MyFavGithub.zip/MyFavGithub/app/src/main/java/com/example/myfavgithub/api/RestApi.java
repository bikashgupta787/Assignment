package com.example.myfavgithub.api;

import com.example.myfavgithub.model.Repo;
import retrofit2.Call;
import retrofit2.Response;
import retrofit2.http.GET;
import retrofit2.http.Path;

public interface RestApi {

    //For Finding the Repository
    @GET("{owner}/{repo}")
    Response<Repo> getRepository(
            @Path("owner") String ownerName,
            @Path("repo") String repoName
    );
}

