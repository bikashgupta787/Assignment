package com.example.myfavgithub.api;


import static com.example.myfavgithub.api.Const.BASE_URL;
import retrofit2.Retrofit;
import retrofit2.adapter.rxjava2.RxJava2CallAdapterFactory;
import retrofit2.converter.gson.GsonConverterFactory;


public class RetroFitIns {
    private static Retrofit retrofit;
    private static RestApi api;

//    private RetroFitIns() {
//    }
//
//    public static RestApi getApi() {
//        if (retrofit == null) {
//            retrofit = new Retrofit.Builder()
//                    .baseUrl(Const.BASE_URL)
//                    .addConverterFactory(GsonConverterFactory.create())
//                    .build();
//        }
//        return retrofit.create(RestApi.class);
//    }

    public static Retrofit getRetrofit() {
        if (retrofit == null) {
            retrofit = new Retrofit.Builder()
                    .baseUrl(BASE_URL)
                    .addConverterFactory(GsonConverterFactory.create())
                    .addCallAdapterFactory(RxJava2CallAdapterFactory.create())
                    .build();
        }
        return retrofit;
    }

    public static RestApi getApi() {
        if (api == null) {
            api = getRetrofit().create(RestApi.class);
        }
        return api;
    }
}
