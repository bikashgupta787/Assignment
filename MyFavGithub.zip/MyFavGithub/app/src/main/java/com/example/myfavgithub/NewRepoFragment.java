package com.example.myfavgithub;

import android.content.Intent;
import android.os.Bundle;
import android.provider.Settings;
import android.text.TextUtils;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.widget.Toolbar;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProvider;

import com.example.myfavgithub.model.Repo;
import com.example.myfavgithub.repodb.Database;
import com.example.myfavgithub.repodb.Entity;
import com.example.myfavgithub.repodb.OnDataBaseAction;
import com.example.myfavgithub.util.Utils;
import com.example.myfavgithub.viewModel.ApiViewModel;
import com.example.myfavgithub.viewModel.Factory;
import com.google.android.material.snackbar.Snackbar;

import java.io.IOException;

import retrofit2.Response;

public class NewRepoFragment  extends Fragment {

        private EditText OwnerName;
        private EditText RepoName;
        private Button addRepositoryBtn;
        private Toolbar addMaterialToolbar;
        private ApiViewModel viewModel;
        private OnDataBaseAction dao;

        @Override
        public View onCreateView(LayoutInflater inflater, ViewGroup container,
                                 Bundle savedInstanceState) {
            View view = inflater.inflate(R.layout.fragment_newrepo, container, false);

            OwnerName = view.findViewById(R.id.owner_edit_text);
            RepoName = view.findViewById(R.id.repo_name);
            addRepositoryBtn = view.findViewById(R.id.add_btn);
            addMaterialToolbar = view.findViewById(R.id.add_material_toolbar);

            //Initializing the database
            dao = Database.getDatabase(getContext()).Dao();

            addMaterialToolbar.setNavigationOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    getFragmentManager().popBackStack();
                }
            });

            if (Utils.isConnected(getContext())) {
                addRepositoryBtn.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        String ownerName = OwnerName.getText().toString();
                        String repoName = RepoName.getText().toString();

                        if (TextUtils.isEmpty(ownerName) || TextUtils.isEmpty(repoName)) {
                            OwnerName.setError("Enter Username/Organization");
                            RepoName.setError("Enter Repo Name");
                            Toast.makeText(getContext(), "Enter correct details", Toast.LENGTH_SHORT).show();
                        } else {
                            try {
                                findTheRepo(ownerName, repoName);
                            } catch (IOException e) {
                                throw new RuntimeException(e);
                            }
                        }
                    }
                });
            } else {
                Snackbar.make(getActivity().findViewById(android.R.id.content), "You're not connected to Internet", Snackbar.LENGTH_INDEFINITE)
                        .setAction("Setting", new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                startActivity(new Intent(Settings.ACTION_SETTINGS));
                            }
                        })
                        .show();
            }

            return view;
        }

        private void findTheRepo(String userName, String repoName) throws IOException {
            Factory factory = new Factory(dao);
            viewModel = new ViewModelProvider(this, factory).get(ApiViewModel.class);
            viewModel.githubRepository(userName, repoName);
            viewModel.getRepoResponse().observe(getViewLifecycleOwner(), new Observer<Response<Repo>>() {
                @Override
                public void onChanged(Response<Repo> response) {
                    if (response.isSuccessful()) {
                        if (response.body() != null) {
                            Log.d(TAG, "Name of the user: " + response.body().getName());
                            String repoName = response.body().getName();
                            String descriptionOfRepo = response.body().getDescription();
                            if (descriptionOfRepo == null) {
                                descriptionOfRepo = "Not Found";
                            }
                            String htmlUrl = response.body().getHtmlUrl();
                            Log.d(TAG, "Description of the user: " + response.body().getDescription());
                            Log.d(TAG, "Html Url of the user: " + response.body().getHtmlUrl());
                            Entity repo = new Entity(repoName, descriptionOfRepo, htmlUrl, userName);
                            viewModel.insertTheRepo(repo);
                            getFragmentManager().popBackStack();
                        } else {
                            OwnerName.getText().clear();
                            RepoName.getText().clear();
                            OwnerName.setError("Enter Correct Username/Organization");
                            RepoName.setError("Enter Correct Repo Name");
                            Toast.makeText(getContext(), "Owner/Repo not found", Toast.LENGTH_SHORT).show();
                        }
                    } else {
                        OwnerName.getText().clear();
                        RepoName.getText().clear();
                        OwnerName.setError("Enter Correct Username/Organization");
                        RepoName.setError("Enter Correct Repo Name");
                        Toast.makeText(getContext(), "Owner/Repo not found", Toast.LENGTH_SHORT).show();
                        Log.d(TAG, "findTheRepo: Getting the error message " + response.message());
                        Log.d(TAG, "findTheRepo: Getting the error message " + response.raw());
                        Log.d(TAG, "findTheRepo: Getting the error message " + response.errorBody());
                        Log.d(TAG, "findTheRepo: Getting the error message " + response.headers());
                    }
                }
            });
        }

        public static final String TAG = "REPO_FRAGMENT";
    }

