package com.example.myfavgithub;

import com.example.myfavgithub.api.RetroFitIns;
import com.example.myfavgithub.model.Repo;
import com.example.myfavgithub.repodb.Entity;
import com.example.myfavgithub.repodb.OnDataBaseAction;

import java.util.List;

import retrofit2.Response;

public class Repository {
    private OnDataBaseAction dao;

    public Repository(OnDataBaseAction dao) {
        this.dao = dao;
    }

    public Response<Repo> getRepo(String ownerName, String repoName) {
        return RetroFitIns.getApi().getRepository(ownerName, repoName);
    }
    public void insertTheRepo(Entity entity) {
        dao.insertRepo(entity);
    }

    public void deleteTheRepo(Entity entity) {
        dao.delete(entity);
    }
    public List<Entity> getAllTheRepo() {
        return dao.getAllRepo();
    }
}


