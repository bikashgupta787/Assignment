package com.example.myfavgithub;

import android.content.Intent;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.provider.Settings;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;

import com.example.myfavgithub.adapter.RepoAdapter;
import com.example.myfavgithub.repodb.Database;
import com.example.myfavgithub.repodb.Entity;
import com.example.myfavgithub.repodb.OnDataBaseAction;
import com.example.myfavgithub.util.Utils;
import com.example.myfavgithub.viewModel.ApiViewModel;
import com.example.myfavgithub.viewModel.Factory;
import com.google.android.material.snackbar.Snackbar;

import java.util.List;

public class RecyclerFragment extends Fragment implements RepoAdapter.OnItemClickListener  {

private RecyclerView repoRecyclerView;
private RepoAdapter repoAdapter;
private ApiViewModel viewModel;
private OnDataBaseAction repodao;
private List<Entity> repoList;

@Override
public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_recycler, container, false);

        repoRecyclerView = view.findViewById(R.id.repo_recycler_view);
        repoAdapter = new RepoAdapter((RepoAdapter.OnItemClickListener) this);

        if (Utils.isConnected(getContext())) {
        repodao = Database.getDatabase(getContext()).Dao();
        Factory factory = new Factory(repodao);
        viewModel = new ViewModelProvider(this, factory).get(ApiViewModel.class);

        repoList = repodao.getAllRepo();
        if (repoList.isEmpty()) {
        view.findViewById(R.id.track_repo_tv).setVisibility(View.VISIBLE);
        view.findViewById(R.id.add_repo_button).setVisibility(View.VISIBLE);
        } else {
        view.findViewById(R.id.track_repo_tv).setVisibility(View.GONE);
        view.findViewById(R.id.add_repo_button).setVisibility(View.GONE);
        repoAdapter.setData(repoList);
        LinearLayoutManager layoutManager = new LinearLayoutManager(getContext());
        repoRecyclerView.setLayoutManager(layoutManager);
        repoRecyclerView.setAdapter(repoAdapter);
        layoutManager.setStackFromEnd(true);
        layoutManager.setReverseLayout(true);
        }

        view.findViewById(R.id.add_repo_button).setOnClickListener(new View.OnClickListener() {
@Override
public void onClick(View v) {
        replaceFragment(new NewRepoFragment());
        }
        });

        androidx.appcompat.widget.Toolbar toolbar = view.findViewById(R.id.home_material_toolbar);
        toolbar.setOnMenuItemClickListener(new androidx.appcompat.widget.Toolbar.OnMenuItemClickListener() {
@Override
public boolean onMenuItemClick(MenuItem menuItem) {
        switch (menuItem.getItemId()) {
        case R.id.add_repo_menu_btn:
        replaceFragment(new NewRepoFragment());
        return true;
//        case R.id.delete_all:
//        new AlertDialog.Builder(getContext())
//        .setTitle("Delete All Repo")
//        .setMessage("Are you sure?")
//        .setNegativeButton("Cancel", null)
//        .setPositiveButton("Delete", (dialog, which) -> {
//        viewModel.deleteEntireDb();
//        Toast.makeText(getContext(), "Entire repo deleted", Toast.LENGTH_SHORT).show();
//        })
//        .show();
//        return true;
default:
        return false;
        }
        }
        });
        } else {
        Snackbar.make(requireActivity().findViewById(android.R.id.content), "You're not connected to Internet", Snackbar.LENGTH_INDEFINITE)
        .setAction("Setting", new View.OnClickListener() {
@Override
public void onClick(View v) {
        startActivity(new Intent(Settings.ACTION_SETTINGS));
        }
        })
        .show();
        }

        return view;
        }

//@Override
//public void onClick(int position) {
//        replaceFragment(new DetailFragment(
//        repoList.get(position).getRepositoryName(),
//        repoList.get(position).getDescriptionRepo(),
//        repoList.get(position).getHtmlUrl(),
//        repoList.get(position).getOwnerName()
//        ));
//        }

        @Override
        public void onClick(int position) {

        }

        public void onShareButtonClick(int position) {
        Intent intent = new Intent(Intent.ACTION_SEND);
        intent.setType("text/plain");
        intent.putExtra(Intent.EXTRA_TEXT, "Checkout this amazing repo at Github " + repoList.get(position).getHtmlUrl());
        startActivity(Intent.createChooser(intent, "Choose the App"));
        }

private void replaceFragment(Fragment fragment) {
        androidx.fragment.app.FragmentTransaction transaction = requireActivity().getSupportFragmentManager().beginTransaction();
        transaction.replace(R.id.fragment_container, fragment);
        transaction.addToBackStack(null);
        transaction.commit();
        }

}