package com.example.myfavgithub.repodb;

import androidx.annotation.NonNull;
import androidx.room.ColumnInfo;
import androidx.room.PrimaryKey;

@androidx.room.Entity(tableName = "RepoTable")
public class Entity {
    @PrimaryKey
    @NonNull
    @ColumnInfo(name = "Repository Name")
    private String repositoryName;

    @ColumnInfo(name = "Description")
    private String descriptionRepo;

    @ColumnInfo(name = "HTML Url")
    private String htmlUrl;

    @ColumnInfo(name = "Owner")
    private String ownerName;

    public Entity(String repositoryName, String descriptionRepo, String htmlUrl, String ownerName) {
        this.repositoryName = repositoryName;
        this.descriptionRepo = descriptionRepo;
        this.htmlUrl = htmlUrl;
        this.ownerName = ownerName;
    }

    public String getRepositoryName() {
        return repositoryName;
    }

    public void setRepositoryName(String repositoryName) {
        this.repositoryName = repositoryName;
    }

    public String getDescriptionRepo() {
        return descriptionRepo;
    }

    public void setDescriptionRepo(String descriptionRepo) {
        this.descriptionRepo = descriptionRepo;
    }

    public String getHtmlUrl() {
        return htmlUrl;
    }

    public void setHtmlUrl(String htmlUrl) {
        this.htmlUrl = htmlUrl;
    }

    public String getOwnerName() {
        return ownerName;
    }

    public void setOwnerName(String ownerName) {
        this.ownerName = ownerName;
    }
}



